
=== Dealsector ===
Contributors: (abc)
Donate link: https://example.com/
Tags: tag1, tag2
Requires at least: 4.7
Tested up to: 1.0
Stable tag: 1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
 
Dealsector Plugin is for Innvetory.
